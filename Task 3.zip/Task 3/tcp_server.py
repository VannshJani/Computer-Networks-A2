import socket
import time
import argparse
import logging
from datetime import datetime

# Set up logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler("server_log.txt"),
        logging.StreamHandler()
    ]
)

def run_server(port, disable_nagle, disable_delayed_ack): # Run TCP server with configurable Nagle and Delayed ACK settings
    # Create a TCP socket
    server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    
    # Set socket options
    server_socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    
    # Disable Nagle's algorithm if requested
    if disable_nagle:
        server_socket.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)
        logging.info("Nagle's algorithm is disabled")
    else:
        logging.info("Nagle's algorithm is enabled")
    
    # Configure Delayed ACK if supported by the platform
    # Kindly note that TCP_QUICKACK is Linux-specific
    if hasattr(socket, 'TCP_QUICKACK') and disable_delayed_ack:
        server_socket.setsockopt(socket.IPPROTO_TCP, socket.TCP_QUICKACK, 1)
        logging.info("Delayed ACK is disabled")
    else:
        logging.info("Delayed ACK setting: system default")
    
    # Bind socket to a specific address and port
    server_socket.bind(('0.0.0.0', port))
    
    # Listen for incoming connections
    server_socket.listen(1)
    logging.info(f"Server listening on port {port}")
    
    try:
        while True:
            # Accept client connection
            client_socket, client_address = server_socket.accept()
            logging.info(f"Connection from {client_address}")
            
            # Performance metrics
            start_time = time.time()
            total_bytes_received = 0
            packet_count = 0
            max_packet_size = 0
            
            try:
                # Process data received from client
                while True:
                    # Receive data
                    data = client_socket.recv(4096)
                    
                    # If no data is received, break the loop
                    if not data:
                        break
                    
                    # Update metrics
                    packet_size = len(data)
                    packet_count += 1
                    total_bytes_received += packet_size
                    max_packet_size = max(max_packet_size, packet_size)
                    
                    # Echo data back to client
                    client_socket.send(data)
                
                # Calculate performance metrics
                end_time = time.time()
                duration = end_time - start_time
                
                if duration > 0:
                    throughput = total_bytes_received / duration  # bytes per second
                    
                    logging.info(f"Connection closed. Performance metrics:")
                    logging.info(f"Duration: {duration:.2f} seconds")
                    logging.info(f"Total bytes received: {total_bytes_received} bytes")
                    logging.info(f"Throughput: {throughput:.2f} bytes/second")
                    logging.info(f"Packet count: {packet_count}")
                    logging.info(f"Maximum packet size: {max_packet_size} bytes")
                    
            except Exception as e:
                logging.error(f"Error processing client data: {e}")
            finally:
                client_socket.close()
                
    except KeyboardInterrupt:
        logging.info("Server shutting down")
    finally:
        server_socket.close()

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description='TCP Server with configurable Nagle and Delayed ACK')
    parser.add_argument('--port', type=int, default=9999, help='Port to listen on')
    parser.add_argument('--disable-nagle', action='store_true', help='Disable Nagle\'s algorithm')
    parser.add_argument('--disable-delayed-ack', action='store_true', help='Disable Delayed ACK')
    
    args = parser.parse_args()
    
    # Log configuration settings
    logging.info(f"Starting server with configuration:")
    logging.info(f"Nagle's algorithm: {'disabled' if args.disable_nagle else 'enabled'}")
    logging.info(f"Delayed ACK: {'disabled' if args.disable_delayed_ack else 'enabled'}")
    
    run_server(args.port, args.disable_nagle, args.disable_delayed_ack)
