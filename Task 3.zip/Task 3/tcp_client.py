import socket
import time
import argparse
import logging
import os
from datetime import datetime

# Set up logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler("client_log.txt"),
        logging.StreamHandler()
    ]
)

def run_client(server_ip, port, disable_nagle, disable_delayed_ack, file_size=4096, rate=40, duration=120):
    """
    Run TCP client with configurable Nagle and Delayed ACK settings
    Send data at specified rate for the given duration
    """
    # Create a test file of the specified size
    test_data = os.urandom(file_size)
    
    # Create a TCP socket
    client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    
    # Set socket options
    # Disable Nagle's algorithm if requested
    if disable_nagle:
        client_socket.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)
        logging.info("Nagle's algorithm is disabled")
    else:
        logging.info("Nagle's algorithm is enabled")
    
    # Configure Delayed ACK if supported by the platform
    # Note: TCP_QUICKACK is Linux-specific
    if hasattr(socket, 'TCP_QUICKACK') and disable_delayed_ack:
        client_socket.setsockopt(socket.IPPROTO_TCP, socket.TCP_QUICKACK, 1)
        logging.info("Delayed ACK is disabled")
    else:
        logging.info("Delayed ACK setting: system default")
    
    try:
        # Connect to the server
        client_socket.connect((server_ip, port))
        logging.info(f"Connected to server {server_ip}:{port}")
        
        # Performance metrics
        start_time = time.time()
        total_bytes_sent = 0
        packet_count = 0
        max_packet_size = 0
        bytes_acknowledged = 0
        
        # Calculate time interval between sending data chunks
        # We want to send 'rate' bytes per second
        interval = 1.0 / (rate / 40)  # Send 40 bytes at a time
        chunk_size = 40
        
        # Start sending data
        logging.info(f"Sending data at {rate} bytes/second for {duration} seconds...")
        
        remaining_time = duration
        while remaining_time > 0:
            send_start = time.time()
            
            # Send a chunk of data
            chunk = test_data[:chunk_size]
            bytes_sent = client_socket.send(chunk)
            
            # Update metrics
            total_bytes_sent += bytes_sent
            packet_count += 1
            max_packet_size = max(max_packet_size, bytes_sent)
            
            # Receive acknowledgment (echo back)
            ack = client_socket.recv(chunk_size)
            bytes_acknowledged += len(ack)
            
            # Calculate how long to sleep to maintain the desired rate
            send_time = time.time() - send_start
            sleep_time = max(0, interval - send_time)
            time.sleep(sleep_time)
            
            # Update remaining time
            elapsed = time.time() - send_start
            remaining_time -= elapsed
        
        # Calculate performance metrics
        end_time = time.time()
        total_duration = end_time - start_time
        
        if total_duration > 0:
            throughput = total_bytes_sent / total_duration  # bps
            goodput = bytes_acknowledged / total_duration  # bps
            packet_loss_rate = 1.0 - (bytes_acknowledged / total_bytes_sent) if total_bytes_sent > 0 else 0
            
            logging.info(f"Transfer completed. Performance metrics:")
            logging.info(f"Duration: {total_duration:.2f} seconds")
            logging.info(f"Total bytes sent: {total_bytes_sent} bytes")
            logging.info(f"Total bytes acknowledged: {bytes_acknowledged} bytes")
            logging.info(f"Throughput: {throughput:.2f} bytes/second")
            logging.info(f"Goodput: {goodput:.2f} bytes/second")
            logging.info(f"Packet loss rate: {packet_loss_rate:.4f}")
            logging.info(f"Packet count: {packet_count}")
            logging.info(f"Maximum packet size: {max_packet_size} bytes")
            
            # Return metrics
            return {
                'duration': total_duration,
                'bytes_sent': total_bytes_sent,
                'bytes_acked': bytes_acknowledged,
                'throughput': throughput,
                'goodput': goodput,
                'packet_loss': packet_loss_rate,
                'packet_count': packet_count,
                'max_packet_size': max_packet_size
            }
            
    except Exception as e:
        logging.error(f"Error during data transfer: {e}")
        return None
    finally:
        client_socket.close()
        logging.info("Connection closed")

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description='TCP Client with configurable Nagle and Delayed ACK')
    parser.add_argument('--server', type=str, required=True, help='Server IP address')
    parser.add_argument('--port', type=int, default=9999, help='Server port')
    parser.add_argument('--disable-nagle', action='store_true', help='Disable Nagle\'s algorithm')
    parser.add_argument('--disable-delayed-ack', action='store_true', help='Disable Delayed ACK')
    parser.add_argument('--file-size', type=int, default=4096, help='Size of test file in bytes')
    parser.add_argument('--rate', type=int, default=40, help='Data transfer rate in bytes/second')
    parser.add_argument('--duration', type=int, default=120, help='Duration of test in seconds')
    
    args = parser.parse_args()
    
    # Log configuration settings
    logging.info(f"Starting client with configuration:")
    logging.info(f"Server: {args.server}:{args.port}")
    logging.info(f"Nagle's algorithm: {'disabled' if args.disable_nagle else 'enabled'}")
    logging.info(f"Delayed ACK: {'disabled' if args.disable_delayed_ack else 'enabled'}")
    logging.info(f"File size: {args.file_size} bytes")
    logging.info(f"Transfer rate: {args.rate} bytes/second")
    logging.info(f"Duration: {args.duration} seconds")
    
    run_client(args.server, args.port, args.disable_nagle, args.disable_delayed_ack, 
              args.file_size, args.rate, args.duration)
