import subprocess
import time
import json
import matplotlib.pyplot as plt
import numpy as np
import os
import csv


def run_test(
    config_name, disable_nagle, disable_delayed_ack
):  # Run a single test with the given configuration
    print(f"Running test: {config_name}")
    print(f"Nagle's Algorithm: {'Disabled' if disable_nagle else 'Enabled'}")
    print(f"Delayed ACK: {'Disabled' if disable_delayed_ack else 'Enabled'}")

    # Start the server process
    server_cmd = ["python", "tcp_server.py", "--port", "9999"]

    if disable_nagle:
        server_cmd.append("--disable-nagle")

    if disable_delayed_ack:
        server_cmd.append("--disable-delayed-ack")

    server_process = subprocess.Popen(server_cmd)

    # Give the server time to start
    time.sleep(2)

    # Start the client process
    client_cmd = [
        "python",
        "tcp_client.py",
        "--server",
        "127.0.0.1",
        "--port",
        "9999",
        "--file-size",
        "4096",
        "--rate",
        "40",
        "--duration",
        "120",
    ]

    if disable_nagle:
        client_cmd.append("--disable-nagle")

    if disable_delayed_ack:
        client_cmd.append("--disable-delayed-ack")

    # Run client and capture output
    client_output = subprocess.check_output(client_cmd, text=True)

    # Terminate server
    server_process.terminate()
    server_process.wait()

    # Sleep before next test
    time.sleep(5)

    # Parse metrics from client logs
    metrics = parse_metrics_from_log("client_log.txt")

    # Add configuration info
    metrics["config_name"] = config_name
    metrics["nagle"] = not disable_nagle
    metrics["delayed_ack"] = not disable_delayed_ack

    return metrics


def parse_metrics_from_log(
    log_file,
):  # Parse performance metrics from the client log file
    metrics = {}

    with open(log_file, "r") as f:
        lines = f.readlines()

    # Finding the metrics section:
    for line in lines:
        if "Throughput:" in line:
            throughput = float(line.split(":")[1].strip().split()[0])
            metrics["throughput"] = throughput
        elif "Goodput:" in line:
            goodput = float(line.split(":")[1].strip().split()[0])
            metrics["goodput"] = goodput
        elif "Packet loss rate:" in line:
            packet_loss = float(line.split(":")[1].strip())
            metrics["packet_loss"] = packet_loss
        elif "Maximum packet size:" in line:
            max_packet_size = int(line.split(":")[1].strip().split()[0])
            metrics["max_packet_size"] = max_packet_size

    return metrics


def run_all_tests():
    # Create results directory
    if not os.path.exists("results"):
        os.makedirs("results")

    results = []

    # Test 1: Nagle enabled, Delayed ACK enabled
    results.append(run_test("Nagle ON, Delayed ACK ON", False, False))

    # Test 2: Nagle enabled, Delayed ACK disabled
    results.append(run_test("Nagle ON, Delayed ACK OFF", False, True))

    # Test 3: Nagle disabled, Delayed ACK enabled
    results.append(run_test("Nagle OFF, Delayed ACK ON", True, False))

    # Test 4: Nagle disabled, Delayed ACK disabled
    results.append(run_test("Nagle OFF, Delayed ACK OFF", True, True))

    with open("results/nagle_test_results.csv", "w", newline="") as csvfile:
        fieldnames = [
            "config_name",
            "nagle",
            "delayed_ack",
            "throughput",
            "goodput",
            "packet_loss",
            "max_packet_size",
        ]
        writer = csv.DictWriter(csvfile, fieldnames=fieldnames)

        writer.writeheader()
        for result in results:
            writer.writerow(result)

    plot_results(results)
    return results


def plot_results(results):
    config_names = [result["config_name"] for result in results]

    plt.figure(figsize=(14, 10))

    # Plot 1: Throughput
    plt.subplot(2, 2, 1)
    throughputs = [result["throughput"] for result in results]
    plt.bar(config_names, throughputs)
    plt.title("Throughput (bytes/second)")
    plt.xticks(rotation=45)
    plt.tight_layout()

    # Plot 2: Goodput
    plt.subplot(2, 2, 2)
    goodputs = [result["goodput"] for result in results]
    plt.bar(config_names, goodputs)
    plt.title("Goodput (bytes/second)")
    plt.xticks(rotation=45)
    plt.tight_layout()

    # Plot 3: Packet Loss Rate
    plt.subplot(2, 2, 3)
    packet_losses = [
        result["packet_loss"] * 100 for result in results
    ]  # Convert to percentage
    plt.bar(config_names, packet_losses)
    plt.title("Packet Loss Rate (%)")
    plt.xticks(rotation=45)
    plt.tight_layout()

    # Plot 4: Maximum Packet Size
    plt.subplot(2, 2, 4)
    max_packet_sizes = [result["max_packet_size"] for result in results]
    plt.bar(config_names, max_packet_sizes)
    plt.title("Maximum Packet Size (bytes)")
    plt.xticks(rotation=45)
    plt.tight_layout()

    plt.savefig("results/nagle_analysis_results.png")
    create_comparison_table(results)


def create_comparison_table(results):
    # Extract data for the table
    config_names = [result["config_name"] for result in results]
    throughputs = [result["throughput"] for result in results]
    goodputs = [result["goodput"] for result in results]
    packet_losses = [result["packet_loss"] for result in results]
    max_packet_sizes = [result["max_packet_size"] for result in results]

    # Create the table
    fig, ax = plt.figure(figsize=(15, 10)), plt.subplot(111)
    ax.axis("tight")
    ax.axis("off")

    # Table data
    table_data = []
    table_data.append(config_names)
    table_data.append([f"{x:.2f}" for x in throughputs])
    table_data.append([f"{x:.2f}" for x in goodputs])
    table_data.append([f"{x:.2f}%" for x in packet_losses])
    table_data.append([f"{x}" for x in max_packet_sizes])

    # Transpose data for display
    table_data = list(map(list, zip(*table_data)))

    # Row and column labels
    row_labels = config_names
    col_labels = [
        "Configuration",
        "Throughput (B/s)",
        "Goodput (B/s)",
        "Packet Loss (%)",
        "Max Packet Size (B)",
    ]

    # Create the table
    table = ax.table(
        cellText=table_data, rowLabels=row_labels, colLabels=col_labels, loc="center"
    )

    # Adjust table appearance
    table.auto_set_font_size(False)
    table.set_fontsize(10)
    table.scale(1.2, 1.5)

    plt.savefig("results/nagle_analysis_table.png", bbox_inches="tight")


if __name__ == "__main__":
    results = run_all_tests()
    print("All tests are completed. Results are saved in the 'results' directory.")
